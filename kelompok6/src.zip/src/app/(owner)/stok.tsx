import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import AppButton from '@/components/atoms/AppButton';
import AppInput from '@/components/atoms/AppInput';
import ProductList from '@/components/organisms/ProductList';
import { StickyMilkColors } from '@/constants/design-tokens';
import { useFonts } from 'expo-font';
import { Poppins_600SemiBold, Poppins_700Bold } from '@expo-google-fonts/poppins';
import { Nunito_400Regular, Nunito_600SemiBold, Nunito_700Bold } from '@expo-google-fonts/nunito';
import { useBahan, type Bahan } from '../../context/bahan-context';

const COLORS = {
  background: StickyMilkColors.cream,
  card: '#FFFFFF',
  brown: StickyMilkColors.primary,
  textDark: StickyMilkColors.textDark,
  textMuted: StickyMilkColors.textMuted,
  border: StickyMilkColors.borderWarm,
  danger: '#EF4444',
  dangerSoft: '#FEE2E2',
  green: '#10B981',
};

const fmt = (n: number) => n.toLocaleString('id-ID');

type Filter = 'semua' | 'hampir' | 'menipis';

const FILTERS: { key: Filter; label: string }[] = [
  { key: 'menipis', label: 'Urut menipis' },
  { key: 'hampir', label: 'Hampir habis' },
  { key: 'semua', label: 'Semua' },
];

// Satuan tiap bahan berbeda (ml, gram, pcs), jadi "seberapa menipis" diukur terhadap batas minimumnya.
// Makin kecil nilainya, makin dekat ke habis.
const rasioStok = (b: Bahan) => (b.minimum > 0 ? b.stok / b.minimum : b.stok > 0 ? Infinity : 0);

export default function StokScreen() {
  const router = useRouter();
  const { bahanList, memuat, galat, refreshBahan } = useBahan();
  const [refreshing, setRefreshing] = useState(false);
  const [query, setQuery] = useState('');
  // Tampilan awal: semua bahan, diurutkan dari yang paling mau habis.
  const [filter, setFilter] = useState<Filter>('menipis');

  const [fontsLoaded] = useFonts({
    Poppins_600SemiBold,
    Poppins_700Bold,
    Nunito_400Regular,
    Nunito_600SemiBold,
    Nunito_700Bold,
  });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = q ? bahanList.filter((b: Bahan) => b.nama.toLowerCase().includes(q)) : bahanList;

    if (filter === 'hampir') {
      list = list.filter((b: Bahan) => b.stok <= b.minimum);
    } else if (filter === 'menipis') {
      list = [...list].sort((a: Bahan, b: Bahan) => {
        const ra = rasioStok(a);
        const rb = rasioStok(b);
        return ra === rb ? 0 : ra < rb ? -1 : 1;
      });
    }
    return list;
  }, [bahanList, query, filter]);

  const hampirHabis = useMemo(() => bahanList.filter((b: Bahan) => b.stok <= b.minimum), [bahanList]);

  if (!fontsLoaded) return null;

  // Tarik layar ke bawah untuk membaca ulang data dari Supabase
  const onRefresh = async () => {
    setRefreshing(true);
    await refreshBahan();
    setRefreshing(false);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Header */}
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.title}>Stok Bahan</Text>
            <Text style={styles.subtitle}>{bahanList.length} bahan baku</Text>
          </View>
          <TouchableOpacity
            style={styles.addCircle}
            activeOpacity={0.8}
            onPress={() => router.push({ pathname: '/(owner)/tambah-bahan', params: { id: '' } })}
          >
            <Ionicons name="add" size={26} color="#FFFFFF" />
          </TouchableOpacity>
        </View>

        {/* Search */}
        <View style={styles.searchBox}>
          <Ionicons name="search-outline" size={20} color={COLORS.textMuted} />
          <AppInput
            style={styles.searchInput}
            placeholder="Cari bahan baku"
            placeholderTextColor={COLORS.textMuted}
            value={query}
            onChangeText={setQuery}
            accessibilityLabel="Cari bahan baku"
          />
        </View>

        {/* Filter */}
        <View style={styles.filterRow}>
          {FILTERS.map((f) => {
            const active = filter === f.key;
            return (
              <TouchableOpacity
                key={f.key}
                style={[styles.chip, active && styles.chipActive]}
                activeOpacity={0.8}
                onPress={() => setFilter(f.key)}
                accessibilityRole="button"
                accessibilityState={{ selected: active }}
              >
                <Text style={[styles.chipText, active && styles.chipTextActive]}>{f.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Gagal memuat dari Supabase */}
        {!!galat && (
          <View style={styles.errorBanner}>
            <Text style={styles.errorText}>{galat}</Text>
            <TouchableOpacity onPress={refreshBahan} activeOpacity={0.7}>
              <Text style={styles.retryText}>Coba lagi</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Warning Banner */}
        {hampirHabis.length > 0 && (
          <View style={styles.warnBanner}>
            <View style={[styles.dot, { backgroundColor: COLORS.danger }]} />
            <Text style={styles.warnText}>{hampirHabis.length} bahan hampir habis</Text>
          </View>
        )}

        {/* Product / Ingredient List */}
        <ProductList itemSpacing={12}>
          {filtered.map((bahan: Bahan) => {
            const low = bahan.stok <= bahan.minimum;
            return (
              <TouchableOpacity
                key={bahan.id}
                style={styles.card}
                activeOpacity={0.7}
                onPress={() =>
                  router.push({
                    pathname: '/(owner)/tambah-bahan',
                    params: { id: bahan.id },
                  })
                }
              >
                <View style={[styles.statusDot, { backgroundColor: low ? COLORS.danger : COLORS.green }]} />
                <View style={styles.info}>
                  <Text style={styles.bahanName} numberOfLines={1}>
                    {bahan.nama}
                  </Text>
                  <Text style={styles.bahanMin}>
                    {'Min. ' + fmt(bahan.minimum) + ' ' + bahan.satuan}
                  </Text>
                </View>
                <View style={styles.stokRight}>
                  <Text style={[styles.stokQty, low && styles.stokQtyLow]}>
                    {fmt(bahan.stok)} {bahan.satuan}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </ProductList>

        {memuat && bahanList.length === 0 && (
          <ActivityIndicator style={styles.loader} color={COLORS.brown} />
        )}

        {!memuat && filtered.length === 0 && (
          <Text style={styles.empty}>
            {bahanList.length === 0
              ? 'Belum ada bahan baku. Tekan + untuk menambahkan.'
              : filter === 'hampir' && !query.trim()
              ? 'Semua stok masih aman.'
              : 'Bahan tidak ditemukan.'}
          </Text>
        )}

        {/* Catat Stok Masuk Button */}
        <AppButton
          style={styles.stokMasukBtn}
          onPress={() => router.push({ pathname: '/(owner)/stok-masuk', params: { id: '' } })}
        >
          <Text style={styles.stokMasukText}>Catat Stok Masuk</Text>
        </AppButton>

        {/* Riwayat Pengadaan */}
        <AppButton
          style={styles.riwayatBtn}
          onPress={() => router.push('/(owner)/riwayat-stok-masuk')}
        >
          <Text style={styles.riwayatText}>Riwayat Pengadaan</Text>
        </AppButton>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  content: { paddingHorizontal: 22, paddingTop: 20, paddingBottom: 40 },

  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontFamily: 'Poppins_700Bold',
    fontSize: 26,
    color: COLORS.textDark,
  },
  subtitle: {
    fontFamily: 'Nunito_400Regular',
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  addCircle: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: COLORS.brown,
    alignItems: 'center',
    justifyContent: 'center',
  },

  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    backgroundColor: COLORS.card,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    paddingHorizontal: 16,
    marginBottom: 14,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 15,
    fontFamily: 'Nunito_400Regular',
    color: COLORS.textDark,
    padding: 0,
  },

  filterRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 14,
  },
  chip: {
    height: 38,
    paddingHorizontal: 16,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.card,
    borderWidth: 1.5,
    borderColor: COLORS.border,
  },
  chipActive: {
    backgroundColor: COLORS.brown,
    borderColor: COLORS.brown,
  },
  chipText: {
    fontFamily: 'Nunito_700Bold',
    fontSize: 13,
    color: COLORS.brown,
  },
  chipTextActive: {
    color: '#FFFFFF',
  },

  errorBanner: {
    backgroundColor: COLORS.dangerSoft,
    borderRadius: 14,
    padding: 12,
    marginBottom: 14,
  },
  errorText: {
    fontFamily: 'Nunito_600SemiBold',
    fontSize: 13,
    color: '#B91C1C',
  },
  retryText: {
    fontFamily: 'Nunito_700Bold',
    fontSize: 13,
    color: COLORS.brown,
    marginTop: 6,
  },
  loader: {
    marginVertical: 30,
  },
  riwayatBtn: {
    height: 54,
    borderRadius: 27,
    backgroundColor: COLORS.card,
    borderWidth: 1.5,
    borderColor: COLORS.brown,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
  },
  riwayatText: {
    fontFamily: 'Poppins_600SemiBold',
    fontSize: 16,
    color: COLORS.brown,
  },

  warnBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: COLORS.dangerSoft,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 14,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  warnText: {
    fontFamily: 'Nunito_600SemiBold',
    fontSize: 14,
    color: COLORS.danger,
  },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.card,
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 18,
    borderWidth: 1,
    borderColor: 'rgba(231, 222, 212, 0.4)',
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 14,
  },
  info: {
    flex: 1,
  },
  bahanName: {
    fontFamily: 'Poppins_700Bold',
    fontSize: 16,
    color: COLORS.textDark,
  },
  bahanMin: {
    fontFamily: 'Nunito_400Regular',
    fontSize: 12,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  stokRight: {
    alignItems: 'flex-end',
  },
  stokQty: {
    fontFamily: 'Poppins_700Bold',
    fontSize: 15,
    color: COLORS.textDark,
  },
  stokQtyLow: {
    color: COLORS.danger,
  },

  empty: {
    fontFamily: 'Nunito_400Regular',
    fontSize: 14,
    color: COLORS.textMuted,
    textAlign: 'center',
    marginVertical: 24,
  },

  stokMasukBtn: {
    height: 54,
    borderRadius: 27,
    backgroundColor: COLORS.brown,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  stokMasukText: {
    fontFamily: 'Poppins_600SemiBold',
    fontSize: 16,
    color: '#FFFFFF',
  },
});